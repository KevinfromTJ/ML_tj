结构
- Lab1
    - Regressors(回归模型类)
    - utilities
        - ...
        - my_Func.py(模型实现的工具函数)
        - my_metrics.py(模型、数据集等等评价的函数)
        - ...
    - my_lr_test.py(各种回归的模型测试)